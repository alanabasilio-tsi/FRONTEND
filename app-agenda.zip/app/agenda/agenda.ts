import { Component } from "@angular/core";

type tipoContato = "amigo" | "família" | "trabalho" | "outro";

class Contato {
    nome: string | undefined;
    telefone: string | undefined;
    email: string | undefined;
    aniversario: Date | undefined;
    tipo: tipoContato | undefined;

    constructor() {
        this.nome = undefined;
        this.telefone = undefined;
        this.email = undefined;
        this.aniversario = undefined;
        this.tipo = undefined;
    }
}

@Component({
    selector: 'app-agenda',
    imports: [],
    templateUrl: './agenda.html'
})
export class Agenda {

    contatos: Contato[] = [];
    mostrarAgenda = false;

    cadastrarContato(contato: Contato) {
        this.contatos.push(contato);
        alert('Contato cadastrado com sucesso!')
        this.mostrarAgenda = false;
    } 

    exibirAgenda(){
        this.mostrarAgenda = true;
    }

}